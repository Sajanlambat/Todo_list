import React from 'react';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';

const SearchAndFilter = ({ searchQuery, filterPriority, handleSearchChange, handlePriorityFilterChange }) => (
  <div style={{ marginBottom: '20px' }}>
    <TextField
      label="Search Tasks"
      value={searchQuery}
      onChange={handleSearchChange}
      fullWidth
      style={{ marginBottom: '20px' }}
    />
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <Typography variant="h6" component="div" style={{ flexGrow: 1 }}>
        Task List
      </Typography>
      <Select
        labelId="filter-priority-label"
        value={filterPriority}
        onChange={handlePriorityFilterChange}
        displayEmpty
        style={{ width: '150px' }}
      >
        <MenuItem value="">
          <em>All Priorities</em>
        </MenuItem>
        <MenuItem value="High">High</MenuItem>
        <MenuItem value="Medium">Medium</MenuItem>
        <MenuItem value="Low">Low</MenuItem>
      </Select>
    </div>
  </div>
);

export default SearchAndFilter;
