import React, { Component } from 'react';
import TaskForm from './TaskForm';
import SearchAndFilter from './SearchAndFilter';
import TaskTable from './TaskTable';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';

class ToDoList extends Component {
  state = {
    tasks: [],
    currentTask: { id: '', title: '', priority: 'Low' },
    searchQuery: '',
    filterPriority: '',
    isEditing: false
  };

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      currentTask: { ...this.state.currentTask, [name]: value },
    });
  };

  addTask = () => {
    const newTask = {
      ...this.state.currentTask,
      id: Date.now(),
    };
    this.setState({
      tasks: [...this.state.tasks, newTask],
      currentTask: { id: '', title: '', priority: 'Low' },
    });
  };

  editTask = (id) => {
    const taskToEdit = this.state.tasks.find(task => task.id === id);
    this.setState({
      currentTask: taskToEdit,
      isEditing: true
    });
  };

  updateTask = () => {
    const updatedTasks = this.state.tasks.map(task =>
      task.id === this.state.currentTask.id ? this.state.currentTask : task
    );
    this.setState({
      tasks: updatedTasks,
      currentTask: { id: '', title: '', priority: 'Low' },
      isEditing: false
    });
  };

  deleteTask = (id) => {
    const filteredTasks = this.state.tasks.filter(task => task.id !== id);
    this.setState({ tasks: filteredTasks });
  };

  searchTasks = () => {
    return this.state.tasks.filter(task =>
      task.title.toLowerCase().includes(this.state.searchQuery.toLowerCase())
    );
  };

  filterTasks = (tasks) => {
    if (this.state.filterPriority) {
      return tasks.filter(task => task.priority === this.state.filterPriority);
    }
    return tasks;
  };

  sortTasks = (tasks) => {
    return tasks.sort((a, b) => {
      const priorities = { High: 3, Medium: 2, Low: 1 };
      return priorities[b.priority] - priorities[a.priority];
    });
  };

  handleFormSubmit = (e) => {
    e.preventDefault();
    this.state.isEditing ? this.updateTask() : this.addTask();
  };

  handleSearchChange = (e) => {
    this.setState({ searchQuery: e.target.value });
  };

  handlePriorityFilterChange = (e) => {
    this.setState({ filterPriority: e.target.value });
  };

  render() {
    const filteredTasks = this.filterTasks(this.searchTasks());
    const sortedTasks = this.sortTasks(filteredTasks);

    return (
      <div
        style={{
          height: '100vh',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          background: 'linear-gradient(to right, #6a11cb, #2575fc)',
        }}
      >
        <Card sx={{ width: '800px', padding: '20px' }}>
          <CardContent>
            <Typography gutterBottom variant="h3" component="div" align="center">
              ToDo List
            </Typography>
            <Divider />
            <TaskForm
              currentTask={this.state.currentTask}
              isEditing={this.state.isEditing}
              handleInputChange={this.handleInputChange}
              handleFormSubmit={this.handleFormSubmit}
            />
            <SearchAndFilter
              searchQuery={this.state.searchQuery}
              filterPriority={this.state.filterPriority}
              handleSearchChange={this.handleSearchChange}
              handlePriorityFilterChange={this.handlePriorityFilterChange}
            />
            <TaskTable
              tasks={sortedTasks}
              onEdit={this.editTask}
              onDelete={this.deleteTask}
            />
          </CardContent>
        </Card>
      </div>
    );
  }
}

export default ToDoList;
