import React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';

const ToDoItem = ({ task, onEdit, onDelete }) => {
  const handleEdit = () => {
    onEdit(task.id);
  };

  const handleDelete = () => {
    onDelete(task.id);
  };

  return (
    <TableRow>
      <TableCell>{task.title}</TableCell>
      <TableCell>{task.priority}</TableCell>
      <TableCell align="center">
        <Button
          variant="outlined"
          color="primary"
          size="small"
          onClick={handleEdit}
          style={{ marginRight: '10px' }}
        >
          Edit
        </Button>
        <Button
          variant="outlined"
          color="secondary"
          size="small"
          onClick={handleDelete}
        >
          Delete
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default ToDoItem;
