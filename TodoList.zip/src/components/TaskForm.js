import React from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const TaskForm = ({ currentTask, isEditing, handleInputChange, handleFormSubmit }) => (
  <form onSubmit={handleFormSubmit} style={{ marginBottom: '20px' }}>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
      <TextField
        name="title"
        label="Task Title"
        value={currentTask.title}
        onChange={handleInputChange}
        required
        margin="normal"
      />
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <InputLabel id="priority-label" style={{ marginRight: '10px' }}>Priority</InputLabel>
        <Select
          labelId="priority-label"
          name="priority"
          value={currentTask.priority}
          onChange={handleInputChange}
          style={{ height: 50 }}
        >
          <MenuItem value="High">High</MenuItem>
          <MenuItem value="Medium">Medium</MenuItem>
          <MenuItem value="Low">Low</MenuItem>
        </Select>
      </div>
    </div>
    <Button
      variant="contained"
      color="primary"
      type="submit"
      fullWidth
      style={{ marginTop: '20px' }}
    >
      {isEditing ? 'Update Task' : 'Add Task'}
    </Button>
  </form>
);

export default TaskForm;
